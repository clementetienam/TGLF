# -*- coding: utf-8 -*-
"""
Created on Tuesday June 06 12:05:47 2019
@author: Dr Clement Etienam

"""
from __future__ import print_function
print(__doc__)

from sklearn.neural_network import MLPClassifier
import numpy as np
import scipy.io as sio
from sklearn.utils import check_random_state
from sklearn.cluster import MiniBatchKMeans
from sklearn.cluster import KMeans
from sklearn import metrics
from scipy.spatial.distance import cdist
import matplotlib.pyplot as plt
import datetime
from sklearn.preprocessing import MinMaxScaler
from numpy import linalg as LA
import pickle
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.metrics import accuracy_score
from keras.utils import to_categorical
from keras.layers import Dense, Activation
from keras.models import Sequential 
import os
import shutil
import multiprocessing
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import RandomForestClassifier
import pandas as pd
oldfolder = os.getcwd()

#def remove():
#    for i in range(1,7):
#        for j in range(30):
#    
#            oldfolder = os.getcwd()
#            folder = 'CCRmodel%d_%d'%(i,j)
#            os.chdir(folder)
#            os.remove("y_train%d.out"%(i))
#            os.remove("X_train%d.out"%(i))
#            os.remove("y_traind%d.out"%(i))
#            os.remove('numrowstest%d.out'%(i))
#            os.chdir(oldfolder)
#            print(" Finished Model %d in cluster %d "%(i,j))
#remove()
#def remove():
#    i=6
#    for j in range(30):
#
#        oldfolder = os.getcwd()
#        folder = 'CCRmodel%d_%d'%(i,j)
#        os.chdir(folder)
#        os.remove("y_train%d.out"%(i))
#        os.remove("X_train%d.out"%(i))
#        os.remove("y_traind%d.out"%(i))
#        os.remove('numrowstest%d.out'%(i))
#        os.chdir(oldfolder)
#        print(" Finished Model %d in cluster %d "%(i,j))
#
#remove()

def remove():
    for i in range(1,7):
        os.remove("inputtest%d.out"%(i))
        os.remove("X_train%d.out"%(i))
        os.remove("y_train%d.out"%(i))
        os.remove("y_traind%d.out"%(i))
        os.remove("labelDA%d.out"%(i))
        os.remove("numrowstest%d.out"%(i))
            
remove()